#!/bin/bash
# EscolarOnline - Build y Push imagenes a ECR (ACT3.3 - 4 microservicios EKS)
REGION="us-east-1"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo "=== Account: $ACCOUNT_ID | Region: $REGION ==="

aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin $ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com

REPOS=("escolaronline-get-products" "escolaronline-create-product" "escolaronline-update-product" "escolaronline-delete-product")
for REPO in "${REPOS[@]}"; do
    aws ecr create-repository --repository-name $REPO --region $REGION 2>/dev/null || echo "$REPO ya existe"
done

docker build --platform linux/arm64 -t escolaronline-get-products ./microserviciosEKSBackend/get-products
docker build --platform linux/arm64 -t escolaronline-create-product ./microserviciosEKSBackend/create-product
docker build --platform linux/arm64 -t escolaronline-update-product ./microserviciosEKSBackend/update-product
docker build --platform linux/arm64 -t escolaronline-delete-product ./microserviciosEKSBackend/delete-product

for REPO in "${REPOS[@]}"; do
    docker tag $REPO $ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/$REPO:latest
    docker push $ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/$REPO:latest
done

echo "=== Push completado ==="

# 2026 - Disenador asignatura: Ignacio A. Pastenet M.
